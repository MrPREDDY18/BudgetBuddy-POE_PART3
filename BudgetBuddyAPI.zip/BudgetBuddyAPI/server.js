const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();

console.log("🚀 Starting BudgetBuddy API...");

const app = express();
const PORT = 3000;

// --- Middleware ---
app.use(cors());
app.use(bodyParser.json());

// --- Debug request logging ---
app.use((req, res, next) => {
  console.log(`📡 Incoming request: ${req.method} ${req.url}`);
  next();
});

console.log("⚙️  Middleware configured");

// --- Database setup ---
console.log("⚙️  Connecting to SQLite database...");
const db = new sqlite3.Database("./budgetbuddy.db", (err) => {
  if (err) console.error("❌ Database connection error:", err.message);
  else {
    console.log("✅ Connected to SQLite database.");
    db.run(
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT
      )`,
      (err) => {
        if (err) console.error("❌ Error creating table:", err.message);
        else console.log("✅ Users table ready");
      }
    );
  }
});

// --- Routes ---
app.get("/", (req, res) => {
  console.log("📥 GET / request received");
  res.json({ message: "🚀 BudgetBuddy API is running!" });
});

app.post("/users", (req, res) => {
  console.log("📥 POST /users request received:", req.body);
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: "Username and password required" });
  
  db.run(`INSERT INTO users (username, password) VALUES (?, ?)`, [username, password], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    console.log("✅ User added with ID:", this.lastID);
    res.json({ id: this.lastID, username });
  });
});

app.get("/users", (req, res) => {
  console.log("📥 GET /users request received");
  db.all(`SELECT * FROM users`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    console.log(`✅ Returning ${rows.length} users`);
    res.json(rows);
  });
});

// --- Start server ---
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Server running on http://0.0.0.0:${PORT}`);
});
