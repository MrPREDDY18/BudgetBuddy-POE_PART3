package com.example.budgetbuddy_poe

data class Transaction(val description: String, val amount: Double)
