package com.example.budgetbuddy_poe

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddTransactionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_transaction)

        val etDescription = findViewById<EditText>(R.id.etDescription)
        val etAmount = findViewById<EditText>(R.id.etAmount)
        val btnSave = findViewById<Button>(R.id.btnSaveTransaction)

        btnSave.setOnClickListener {
            val description = etDescription.text.toString()
            val amountText = etAmount.text.toString()

            if (description.isNotBlank() && amountText.isNotBlank()) {
                val amount = amountText.toDoubleOrNull()
                if (amount != null) {
                    val resultIntent = Intent().apply {
                        putExtra("description", description)
                        putExtra("amount", amount)
                    }
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                } else {
                    Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
