package com.example.budgetbuddy_poe

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetGoalsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_goals)

        val etGoal = findViewById<EditText>(R.id.etGoalAmount)
        val btnSaveGoal = findViewById<Button>(R.id.btnSaveGoal)

        btnSaveGoal.setOnClickListener {
            val goalText = etGoal.text.toString()
            if (goalText.isNotBlank()) {
                val goalValue = goalText.toFloatOrNull()
                if (goalValue != null) {
                    val resultIntent = Intent().apply {
                        putExtra("goal", goalValue)
                    }
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                } else {
                    Toast.makeText(this, "Please enter a valid goal amount", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter your goal", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
