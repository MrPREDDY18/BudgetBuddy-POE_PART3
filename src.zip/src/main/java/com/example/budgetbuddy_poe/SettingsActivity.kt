package com.example.budgetbuddy_poe

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import java.util.*

class SettingsActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        auth = FirebaseAuth.getInstance()

        // Initialize views
        val switchNotifications = findViewById<Switch>(R.id.switchNotifications)
        val switchDarkMode = findViewById<Switch>(R.id.switchDarkMode)
        val editUsername = findViewById<EditText>(R.id.editUsername)
        val editEmail = findViewById<EditText>(R.id.editEmail)
        val spinnerLanguage = findViewById<Spinner>(R.id.spinnerLanguage)
        val spinnerCurrency = findViewById<Spinner>(R.id.spinnerCurrency)
        val btnChangePassword = findViewById<Button>(R.id.btnChangePassword)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnLogout = findViewById<Button>(R.id.btnLogout)
        val btnDeleteAccount = findViewById<Button>(R.id.btnDeleteAccount)

        val sharedPref = getSharedPreferences("AppSettings", Context.MODE_PRIVATE)

        // Load saved settings
        switchNotifications.isChecked = sharedPref.getBoolean("notifications_enabled", true)
        switchDarkMode.isChecked = sharedPref.getBoolean("dark_mode", false)
        editUsername.setText(sharedPref.getString("username", ""))
        editEmail.setText(auth.currentUser?.email ?: "")

        // Setup Language Spinner (with 2 SA languages)
        val languages = arrayOf("English", "Afrikaans", "isiZulu", "isiXhosa")
        val languageAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, languages)
        languageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerLanguage.adapter = languageAdapter

        val savedLanguage = sharedPref.getString("language", "English")
        spinnerLanguage.setSelection(languages.indexOf(savedLanguage))

        // Setup Currency Spinner
        val currencies = arrayOf("ZAR (R)", "USD ($)", "EUR (€)", "GBP (£)")
        val currencyAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencies)
        currencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCurrency.adapter = currencyAdapter

        val savedCurrency = sharedPref.getString("currency", "ZAR (R)")
        spinnerCurrency.setSelection(currencies.indexOf(savedCurrency))

        // Dark Mode Toggle
        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            val editor = sharedPref.edit()
            editor.putBoolean("dark_mode", isChecked)
            editor.apply()

            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        // Language Change
        spinnerLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selectedLanguage = languages[position]
                val editor = sharedPref.edit()
                editor.putString("language", selectedLanguage)
                editor.apply()

                // Apply language change
                changeLanguage(selectedLanguage)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Save Settings
        btnSave.setOnClickListener {
            val editor = sharedPref.edit()
            editor.putBoolean("notifications_enabled", switchNotifications.isChecked)
            editor.putString("username", editUsername.text.toString())
            editor.putString("currency", spinnerCurrency.selectedItem.toString())
            editor.apply()

            // Update username in Firebase (if using Firestore)
            updateUsernameInDatabase(editUsername.text.toString())

            Toast.makeText(this, getString(R.string.settings_saved), Toast.LENGTH_SHORT).show()
        }

        // Change Password
        btnChangePassword.setOnClickListener {
            showChangePasswordDialog()
        }

        // Logout
        btnLogout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.logout))
                .setMessage(getString(R.string.logout_confirmation))
                .setPositiveButton(getString(R.string.yes)) { _, _ ->
                    auth.signOut()
                    // Clear shared preferences
                    sharedPref.edit().clear().apply()

                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
                .setNegativeButton(getString(R.string.no), null)
                .show()
        }

        // Delete Account
        btnDeleteAccount.setOnClickListener {
            showDeleteAccountDialog()
        }
    }

    private fun showChangePasswordDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_change_password, null)
        val editCurrentPassword = dialogView.findViewById<EditText>(R.id.editCurrentPassword)
        val editNewPassword = dialogView.findViewById<EditText>(R.id.editNewPassword)
        val editConfirmPassword = dialogView.findViewById<EditText>(R.id.editConfirmPassword)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.change_password))
            .setView(dialogView)
            .setPositiveButton(getString(R.string.change)) { _, _ ->
                val currentPassword = editCurrentPassword.text.toString()
                val newPassword = editNewPassword.text.toString()
                val confirmPassword = editConfirmPassword.text.toString()

                when {
                    currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty() -> {
                        Toast.makeText(this, getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show()
                    }
                    newPassword.length < 6 -> {
                        Toast.makeText(this, getString(R.string.password_too_short), Toast.LENGTH_SHORT).show()
                    }
                    newPassword != confirmPassword -> {
                        Toast.makeText(this, getString(R.string.passwords_dont_match), Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        changePassword(currentPassword, newPassword)
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun changePassword(currentPassword: String, newPassword: String) {
        val user = auth.currentUser
        val email = user?.email

        if (user != null && email != null) {
            // Re-authenticate user before changing password
            val credential = EmailAuthProvider.getCredential(email, currentPassword)

            user.reauthenticate(credential)
                .addOnSuccessListener {
                    user.updatePassword(newPassword)
                        .addOnSuccessListener {
                            Toast.makeText(this, getString(R.string.password_changed_success), Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, getString(R.string.password_change_failed) + ": ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, getString(R.string.incorrect_current_password), Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun showDeleteAccountDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_account))
            .setMessage(getString(R.string.delete_account_warning))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                val user = auth.currentUser
                user?.delete()
                    ?.addOnSuccessListener {
                        Toast.makeText(this, getString(R.string.account_deleted), Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    }
                    ?.addOnFailureListener { e ->
                        Toast.makeText(this, getString(R.string.delete_failed) + ": ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun changeLanguage(language: String) {
        val locale = when (language) {
            "Afrikaans" -> Locale("af")
            "isiZulu" -> Locale("zu")
            "isiXhosa" -> Locale("xh")
            else -> Locale("en")
        }

        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)

        // Restart activity to apply language change
        recreate()
    }

    private fun updateUsernameInDatabase(username: String) {
        // If using Firebase Firestore
        /*
        val db = FirebaseFirestore.getInstance()
        val userId = auth.currentUser?.uid

        if (userId != null) {
            db.collection("users").document(userId)
                .update("username", username)
                .addOnSuccessListener {
                    // Username updated successfully
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to update username: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
        */

        // If using your own REST API
        /*
        val retrofit = RetrofitClient.getInstance()
        val apiService = retrofit.create(ApiService::class.java)

        val userId = sharedPref.getInt("user_id", -1)
        val call = apiService.updateUsername(userId, username)

        call.enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    // Success
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@SettingsActivity, "Network error", Toast.LENGTH_SHORT).show()
            }
        })
        */
    }
}