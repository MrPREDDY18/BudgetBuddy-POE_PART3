package com.example.budgetbuddy_poe

data class OnboardingItem(
    val imageRes: Int,       // This is required by the adapter
    val title: String,
    val description: String
)