package com.example.budgetbuddy_poe

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rvTransactions = findViewById<RecyclerView>(R.id.rvTransactions)
        val btnAddTransaction = findViewById<Button>(R.id.btnAddTransaction)
        val btnSetGoals = findViewById<Button>(R.id.btnSetGoals)

        // TODO: implement functionality later
    }
}
