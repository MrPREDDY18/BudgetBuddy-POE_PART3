package com.example.budgetbuddy_poe

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val ADD_TRANSACTION_REQUEST_CODE = 1
    private val SET_GOAL_REQUEST_CODE = 2

    private lateinit var adapter: TransactionAdapter
    private val transactions = mutableListOf<Transaction>()

    private lateinit var tvGoal: TextView
    private lateinit var tvIncome: TextView
    private lateinit var tvExpenses: TextView
    private lateinit var tvBalance: TextView

    private var goalAmount: Float = 0.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAddTransaction = findViewById<Button>(R.id.btnAddTransaction)
        val btnSetGoals = findViewById<Button>(R.id.btnSetGoals)
        val btnSettings = findViewById<Button>(R.id.btnSettings) // 🔹 NEW
        val rvTransactions = findViewById<RecyclerView>(R.id.rvTransactions)

        tvGoal = findViewById(R.id.tvGoal)
        tvIncome = findViewById(R.id.tvIncome)
        tvExpenses = findViewById(R.id.tvExpenses)
        tvBalance = findViewById(R.id.tvBalance)

        // RecyclerView setup
        rvTransactions.layoutManager = LinearLayoutManager(this)
        adapter = TransactionAdapter(transactions)
        rvTransactions.adapter = adapter

        // Launch AddTransactionActivity
        btnAddTransaction.setOnClickListener {
            val intent = Intent(this, AddTransactionActivity::class.java)
            startActivityForResult(intent, ADD_TRANSACTION_REQUEST_CODE)
        }

        // Launch SetGoalsActivity
        btnSetGoals.setOnClickListener {
            val intent = Intent(this, SetGoalsActivity::class.java)
            startActivityForResult(intent, SET_GOAL_REQUEST_CODE)
        }

        // 🔹 Launch SettingsActivity
        btnSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        // Initial dummy data (optional)
        transactions.addAll(
            listOf(
                Transaction("Groceries", -200.0),
                Transaction("Electricity Bill", -500.0),
                Transaction("Salary", 5000.0)
            )
        )
        adapter.notifyDataSetChanged()
        updateSummary()

        // Set default goal color (grey) if no goal is set yet
        tvGoal.setTextColor(Color.parseColor("#9E9E9E"))

        // 🔹 Load saved settings (username, notifications)
        loadSavedSettings()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Handle new transaction
        if (requestCode == ADD_TRANSACTION_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val description = data?.getStringExtra("description")
            val amount = data?.getDoubleExtra("amount", 0.0)

            if (!description.isNullOrBlank() && amount != null) {
                val newTransaction = Transaction(description, amount)
                transactions.add(newTransaction)
                adapter.notifyItemInserted(transactions.size - 1)
                updateSummary()
            }
        }

        // Handle new goal
        if (requestCode == SET_GOAL_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            goalAmount = data?.getFloatExtra("goal", 0.0f) ?: 0.0f
            tvGoal.text = "Goal: R${"%.2f".format(goalAmount)}"
            // Set goal text color to light blue when goal is set
            tvGoal.setTextColor(Color.parseColor("#03A9F4"))
        }
    }

    private fun updateSummary() {
        val income = transactions.filter { it.amount > 0 }.sumOf { it.amount }
        val expenses = transactions.filter { it.amount < 0 }.sumOf { it.amount }
        val balance = income + expenses

        tvIncome.text = "Income: R${"%.2f".format(income)}"
        tvExpenses.text = "Expenses: R${"%.2f".format(expenses)}"
        tvBalance.text = "Balance: R${"%.2f".format(balance)}"

        // Set text colors for the summary values
        tvIncome.setTextColor(Color.parseColor("#4CAF50"))  // Green for income
        tvExpenses.setTextColor(Color.parseColor("#F44336")) // Red for expenses
        tvBalance.setTextColor(Color.parseColor("#2196F3")) // Blue for balance
    }

    // 🔹 Load and show saved settings
    private fun loadSavedSettings() {
        val prefs = getSharedPreferences("AppSettings", Context.MODE_PRIVATE)
        val username = prefs.getString("username", "User")
        val notificationsEnabled = prefs.getBoolean("notifications_enabled", true)

        // Just show a toast for demo purposes
        Toast.makeText(this, "Welcome back, $username!", Toast.LENGTH_SHORT).show()

        // You can also use the settings to change behavior or UI if needed
    }
}
