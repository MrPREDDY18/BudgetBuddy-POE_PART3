package com.example.budgetbuddy_poe

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class OnBoardingActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var dotsIndicator: TabLayout
    private lateinit var btnStart: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding) // XML layout file

        // Find views
        viewPager = findViewById(R.id.viewPager)
        dotsIndicator = findViewById(R.id.dotsIndicator)
        btnStart = findViewById(R.id.btnStart)

        // Create onboarding items
        val onboardingItems = listOf(
            OnboardingItem(
                R.drawable.ic_finances,
                "Your finances in one place.",
                "Get the big picture on all your money. Connect your bank, track cash, or import data."
            ),
            OnboardingItem(
                R.drawable.ic_bank,
                "Connect your bank.",
                "Connect all your accounts from any bank. Add savings, credit cards, PayPal and more."
            ),
            OnboardingItem(
                R.drawable.ic_spending,
                "Track your spending.",
                "Track and analyse spending immediately and automatically through our bank connection."
            ),
            OnboardingItem(
                R.drawable.ic_goals,
                "Set up your goals.",
                "Track and follow what matters to you. Save for important things."
            ),
            OnboardingItem(
                R.drawable.ic_budget,
                "Budget your money.",
                "Build healthy financial habits. Control unnecessary expenses."
            ),
            OnboardingItem(
                R.drawable.ic_plan,
                "Follow your plans and dreams.",
                "Build your financial life. Make the right financial decisions. See only what is important for you."
            )
        )

        // Set adapter
        val adapter = OnboardingAdapter(onboardingItems)
        viewPager.adapter = adapter

        // Attach TabLayout (dots) to ViewPager
        TabLayoutMediator(dotsIndicator, viewPager) { tab, _ ->
            // Dots don't need text, indicator is enough
        }.attach()

        // Start button click
        btnStart.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
